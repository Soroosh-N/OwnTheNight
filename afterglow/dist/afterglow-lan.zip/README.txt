APEX AFTERGLOW - LAN EDITION

Install Node.js on the host computer.
Extract this entire archive. Open a terminal in the extracted folder.
Run: node lan-server.mjs

The terminal prints a localhost URL and the address for other computers.
Everyone opens the host network address in their browser on the same LAN.
Click LAN MULTIPLAYER. The host creates a room and shares its room code.
Other players join with that code. The host starts the race. Up to six players.
AI fills empty slots. Each player can choose a different car.
If Windows asks, allow Node.js on your private network.
Ctrl+C stops the server. No installation of npm packages is required.

Controls: W/A/S/D or arrows; Shift nitro; Space handbrake; P autopilot;
R recover to last checkpoint; Escape pause (LAN host only).
